package abdn.scnu.ai;
import java.util.*;

public class Game implements GameControls{
    public PlayerGameGrid PGameGrid;
    public OpponentGameGrid OGameGrid;
    public Game (int number_of_rows,int number_of_columns,int number_of_ships){
        //constructor that create an object of PlayerGameGrid and an object of OpponentGameGrid.
        PGameGrid=new PlayerGameGrid(number_of_rows,number_of_columns,number_of_ships);
        OGameGrid=new OpponentGameGrid(number_of_rows,number_of_columns,number_of_ships);

    }

    public PlayerGameGrid getPlayersGrid(){
        //retrieve player's grid.
        return PGameGrid;
    }

    public OpponentGameGrid getOpponentssGrid(){
        //retrieve opponent's grid.
        return OGameGrid;
    }

    public void exitGame(String input) {
        //ends the program.
        boolean status=input.contains("exit");
        if (status == true) {
            System.out.println("Exiting game – thank you for playing");
            System.exit(0);
        }
    }

    public boolean checkVictory() {
        // check whether either all opponent’s or player’s ships have been destroyed.
        int numHitOShips=0;
        for (int i=0;i < OGameGrid.ships.length;i++) {
            if (OGameGrid.ships[i].getHits() == 3) {
                numHitOShips++;
            }
        }
        if (numHitOShips == OGameGrid.ships.length) {
            System.out.println("You have won!");
            return true;
        }
        int numHitPShips=0;
        for (int j=0;j < PGameGrid.ships.length;j++) {
            if (PGameGrid.ships[j].getHits() == 3) {
                numHitPShips++;
            }
        }
        if (numHitPShips == PGameGrid.ships.length) {
            System.out.println("You have lost!");
            return true;
        }
        return false;
    }

    public void playRound(String input) {
        //display a round of game, including player and opponent's operation.
        String[] coordinate=input.split(",");
        int x=Integer.parseInt(coordinate[0]);
        int y=Integer.parseInt(coordinate[1]);
        if (OGameGrid.gameGrid[x][y] == "X" || OGameGrid.gameGrid[x][y] == "%") {
            System.out.print("Player is attacking\n");
            System.out.println("You have attack this position.");
        }
        else {
            for (int i=0;i < OGameGrid.ships.length;i++) {
                if (OGameGrid.ships[i].checkAttack(x, y) == true) {
                    System.out.print("Player is attacking\n");
                    System.out.println("HIT " + OGameGrid.ships[i].name + "!!!");
                    OGameGrid.gameGrid[x][y] = "X";
                }
            }
            if (OGameGrid.gameGrid[x][y] != "X") {
                System.out.print("Player is attacking\n");
                System.out.println("MISS!!!");
                OGameGrid.gameGrid[x][y]="%";
            }
        }
        Random randcoordinate=new Random();
        int randx= randcoordinate.nextInt(PGameGrid.height);
        int randy=randcoordinate.nextInt(PGameGrid.width);
        if (PGameGrid.gameGrid[x][y] == "X" || PGameGrid.gameGrid[x][y] == "%") {
            System.out.print("Opponent is attacking\n");
            System.out.println("You have attack this position.");
        }
        else {
            for (int m = 0; m < PGameGrid.ships.length; m++) {
                if (PGameGrid.ships[m].checkAttack(randx, randy) == true) {
                    System.out.print("Opponent is attacking\n");
                    System.out.println("HIT " + PGameGrid.ships[m].name + "!!!");
                    PGameGrid.gameGrid[randx][randy] = "X";
                }
            }
            if (PGameGrid.gameGrid[randx][randy] != "X") {
                System.out.print("Opponent is attacking\n");
                System.out.println("MISS!!!");
                PGameGrid.gameGrid[randx][randy] = "%";
            }
        }
        PGameGrid.printGrid();
        OGameGrid.printGrid();
    }
}
