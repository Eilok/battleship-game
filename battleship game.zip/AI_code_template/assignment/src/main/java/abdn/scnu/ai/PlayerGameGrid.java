package abdn.scnu.ai;

public class PlayerGameGrid extends GameGrid {
    public PlayerGameGrid(int width, int height, int numberOfShips) {
        //constructor that inherits the parameters in the GameGrid.
        super(width,height,numberOfShips);
    }

    public void printGrid() {
        //print the player's grid out.
        System.out.println("Player's grid");
        for (int row=0;row < gameGrid.length;row++) {
            for (int column=0;column < gameGrid[row].length;column++) {
                if (column == (gameGrid[row].length-1)) {
                    System.out.println(gameGrid[row][column]);
                }
                else {
                    System.out.print(gameGrid[row][column]);
                }
            }
        }
    }
}
