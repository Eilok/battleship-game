package abdn.scnu.ai;
import java.util.*; //to import class Random

public class BattleShip extends AbstractBattleShip {

    public BattleShip(String name) {
        //define a class constructor to set the name of the ship and decide the ship orientation.
        this.name=name;
        char[] OriStore={'h','v'};
        Random RandOri=new Random();
        if (OriStore[RandOri.nextInt(2)] == 'h') {
            this.shipOrientation="horizontal";
        }
        else {
            this.shipOrientation="vertical";
        }
    }

    @Override
    public String getName(){
        //access the name of the ship
        return name;
    }

    @Override
    public String getShipOrientation() {
        //access the orientation of the ship
        return shipOrientation;
    }

    @Override
    public void setHits(int hits) {
        //set the number of hits
        this.hits = hits;
    }

    @Override
    public int getHits() {
        //access the number of hits
        return hits;
    }

    @Override
    public void setShipCoordinates(int[][] shipCoordinates) {
        //store the ship coordinates
        this.shipCoordinates=shipCoordinates;
    }

    @Override
    public int[][] getShipCoordinates() {
        //access the ship coordinates
        return shipCoordinates;
    }

    @Override
    public boolean checkAttack(int row, int column) {
        //check if hitting the ship successfully. If this is case, return true. Otherwise, return false.
        if (hits == 3) {
            return false;
        }
        else {
            for (int i=0;i < shipCoordinates.length;i++) {
                if (shipCoordinates[i][0] == row && shipCoordinates[i][1] == column) {
                    hits+=1;
                    shipCoordinates[i][0]=-1;
                    shipCoordinates[i][1]=-1;
                    return true;
                }
            }
            return false;
        }

    }
}
