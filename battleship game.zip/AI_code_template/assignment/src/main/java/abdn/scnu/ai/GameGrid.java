package abdn.scnu.ai;

import java.util.*;
public class GameGrid extends AbstractGameGrid {
    public int width;
    public int height;
    public int numberOfShips;
    //public  BattleShip[] ships;

    public GameGrid(int width, int height, int numberOfShips) {
        //constructor that takes three parametres: width, height and number of ships, then create the game grid.
        this.width=width;
        this.height=height;
        this.numberOfShips=numberOfShips;
        initializeGrid();
        generateShips(numberOfShips);
        for (int i=0;i < numberOfShips;i++) {
            placeShip(ships[i]);
        }

    }

    @Override
    public void initializeGrid() {
        //initialize the game grid according to the input.
        gameGrid=new String[height][width];
        for (int row=0;row < gameGrid.length;row++) {
            for (int column=0;column < gameGrid[row].length;column++) {
                gameGrid[row][column]=".";
            }
        }
    }

    @Override
    public void generateShips (int numberOfShips) {
        //generate required number of ships and store it in the ships array.
        ships=new AbstractBattleShip[numberOfShips];
        for (int num=0;num < ships.length;num++) {
            String s=Integer.toString(num+1);
            ships[num]=new BattleShip("Ship "+s);
        }
    }

    @Override
    public void placeShip (AbstractBattleShip ship) {
        //place ships randomly on the grid. Then store its coordinates in the 2D-array.
        String orientation=ship.getShipOrientation();
        Random rand=new Random();
        int randrow=rand.nextInt(height);
        int randcolumn=rand.nextInt(width);
        gameGrid[randrow][randcolumn]="*";
        int[][] shipcoordinates=new int[3][2];
        shipcoordinates[0][0]=randrow;
        shipcoordinates[0][1]=randcolumn;

        if (orientation == "horizontal"){
            if (randcolumn == 0) {
                randcolumn+=1;
                gameGrid[randrow][randcolumn]="*";
                shipcoordinates[1][0]=randrow;
                shipcoordinates[1][1]=randcolumn;
                randcolumn+=1;
                gameGrid[randrow][randcolumn]="*";
                shipcoordinates[2][0]=randrow;
                shipcoordinates[2][1]=randcolumn;
            }
            else if (randcolumn == width-1) {
                randcolumn-=1;
                gameGrid[randrow][randcolumn]="*";
                shipcoordinates[1][0]=randrow;
                shipcoordinates[1][1]=randcolumn;
                randcolumn-=1;
                gameGrid[randrow][randcolumn]="*";
                shipcoordinates[2][0]=randrow;
                shipcoordinates[2][1]=randcolumn;
            }
            else {
                int[] index={randcolumn-1,randcolumn+1};
                randcolumn=index[rand.nextInt(2)];
                gameGrid[randrow][randcolumn]="*";
                shipcoordinates[1][0]=randrow;
                shipcoordinates[1][1]=randcolumn;
                if (randcolumn == width-1) {
                    gameGrid[randrow][randcolumn-2]="*";
                    shipcoordinates[2][0]=randrow;
                    shipcoordinates[2][1]=randcolumn-2;
                }
                else if (randcolumn == 0) {
                    gameGrid[randrow][randcolumn+2]="*";
                    shipcoordinates[2][0]=randrow;
                    shipcoordinates[2][1]=randcolumn+2;
                }
                else {
                    if (gameGrid[randrow][randcolumn+1] == "*") {
                        int[] index1={randcolumn-1,randcolumn+2};
                        randcolumn=index1[rand.nextInt(2)];
                        gameGrid[randrow][randcolumn]="*";
                        shipcoordinates[2][0]=randrow;
                        shipcoordinates[2][1]=randcolumn;
                    }
                    else {
                        int[] index2={randcolumn-2,randcolumn+1};
                        randcolumn=index2[rand.nextInt(2)];
                        gameGrid[randrow][randcolumn]="*";
                        shipcoordinates[2][0]=randrow;
                        shipcoordinates[2][1]=randcolumn;
                    }
                }
            }
        }
        else {
            if (randrow == 0) {
                randrow+=1;
                gameGrid[randrow][randcolumn]="*";
                shipcoordinates[1][0]=randrow;
                shipcoordinates[1][1]=randcolumn;
                randrow+=1;
                gameGrid[randrow][randcolumn]="*";
                shipcoordinates[2][0]=randrow;
                shipcoordinates[2][1]=randcolumn;
            }
            else if (randrow == height-1) {
                randrow-=1;
                gameGrid[randrow][randcolumn]="*";
                shipcoordinates[1][0]=randrow;
                shipcoordinates[1][1]=randcolumn;
                randrow-=1;
                gameGrid[randrow][randcolumn]="*";
                shipcoordinates[2][0]=randrow;
                shipcoordinates[2][1]=randcolumn;
            }
            else {
                int[] index={randrow-1,randrow+1};
                randrow=index[rand.nextInt(2)];
                gameGrid[randrow][randcolumn]="*";
                shipcoordinates[1][0]=randrow;
                shipcoordinates[1][1]=randcolumn;
                if (randrow == height-1) {
                    gameGrid[randrow-2][randcolumn]="*";
                    shipcoordinates[2][0]=randrow-2;
                    shipcoordinates[2][1]=randcolumn;
                }
                else if (randrow == 0) {
                    gameGrid[randrow+2][randcolumn]="*";
                    shipcoordinates[2][0]=randrow+2;
                    shipcoordinates[2][1]=randcolumn;
                }
                else {
                    if (gameGrid[randrow+1][randcolumn] == "*") {
                        int[] index1={randrow-1,randrow+2};
                        randrow=index1[rand.nextInt(2)];
                        gameGrid[randrow][randcolumn]="*";
                        shipcoordinates[2][0]=randrow;
                        shipcoordinates[2][1]=randcolumn;
                    }
                    else {
                        int[] index2={randrow-2,randrow+1};
                        randrow=index2[rand.nextInt(2)];
                        gameGrid[randrow][randcolumn]="*";
                        shipcoordinates[2][0]=randrow;
                        shipcoordinates[2][1]=randcolumn;
                    }
                }
            }
        }
        ship.setShipCoordinates(shipcoordinates);
    }

}
