package abdn.scnu.ai;
import java.util.Scanner;  //needed for input
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class RunGame {

    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        System.out.print("Please enter the width of game grid:");  //assess the width of grid.
        int width=input.nextInt();
        System.out.print("Please enter the height of game grid:");  //assess the height of grid.
        int height=input.nextInt();
        System.out.print("Please enter the number of ships:");  //assess the number of ships on the grid.
        int number_of_ships=input.nextInt();
        Game gameAction=new Game(width,height,number_of_ships);   //create an instance of Game.
        gameAction.PGameGrid.printGrid();
        gameAction.OGameGrid.printGrid();
        Scanner stringinput=new Scanner(System.in);
        System.out.print("Please enter the position you wish to attack(type 'exit' to quit):\n");
        String hitcoordinate=stringinput.nextLine();
        if (hitcoordinate.matches("\\d*,\\d*") != true && hitcoordinate.contains("exit") != true) {
            //check if the input satisfy the requirement.
            throw new IllegalArgumentException("Incorrect input.");
        }
        gameAction.exitGame(hitcoordinate);  //check if user need to exit.
        gameAction.playRound(hitcoordinate);  //begin the game.
        while (gameAction.checkVictory() != true) {
            System.out.print("Please enter the position you wish to attack(type 'exit' to quit):\n");
            String hitcoordinate2=stringinput.nextLine();
            if (hitcoordinate2.matches("\\d*,\\d*") != true && hitcoordinate.contains("exit") != true) {
                //check if the input satisfy the requirement.
                throw new IllegalArgumentException("Incorrect input.");
            }
            gameAction.exitGame(hitcoordinate2);  //check if user need to exit.
            gameAction.playRound(hitcoordinate2);
        }
    }
}
